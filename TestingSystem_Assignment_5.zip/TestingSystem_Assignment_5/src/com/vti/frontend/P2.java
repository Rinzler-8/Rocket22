package com.vti.frontend;

import com.vti.backend.Ex2;

public class P2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Ex2 ex2 = new Ex2();
		ex2.q1();
		
	}

}
