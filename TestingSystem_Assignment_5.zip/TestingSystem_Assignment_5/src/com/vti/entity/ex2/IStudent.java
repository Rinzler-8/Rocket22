package com.vti.entity.ex2;

public interface IStudent {
	public void diemDanh();
	public void hocBai();
	public void donVeSinh();
}
